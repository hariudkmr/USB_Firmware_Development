
#ifndef USBD_FRAMEWORK_H_
#define USBD_FRAMEWORK_H_

#include "usbd_driver.h"

void usbd_initialize();
void usbd_poll();

#endif /* USBD_FRAMEWORK_H_ */
