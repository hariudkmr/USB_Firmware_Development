
#ifndef HELPERS_MATH_H_
#define HELPERS_MATH_H_

#define MIN(a,b) (((a)<(b))?(a):(b))

#endif /* HELPERS_MATH_H_ */
